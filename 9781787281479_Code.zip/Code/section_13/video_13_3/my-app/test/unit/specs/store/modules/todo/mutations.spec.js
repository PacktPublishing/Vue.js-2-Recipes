import mutations from '@/store/modules/todo/mutations'

describe('mutations', () => {
  /**
   * Unit Test which will test the ADD-mutation.
   */
  it('ADD', () => {
    // Initialize the test.
    const state = {
      all: [],
    };

    // Apply mutation
    mutations.ADD(state, 'hello world!');
    mutations.ADD(state, 'hello world!2');

    // Assert result
    expect(state.all.length).to.equal(2);
    expect(state.all[1].id).to.equal(2);
  });

  /**
   * Unit Test which will test the REMOVE-mutation.
   */
  it('REMOVE', () => {
    // Initialize the test.
    const todo = {
      title: 'Hello World!',
      completed: false,
      id: 1,
    };
    const state = {
      all: [todo],
    };

    // Apply mutation
    mutations.REMOVE(state, todo);

    // Assert result
    expect(state.all.length).to.equal(0);
  });

  /**
   * Unit Test which will test the TOGGLE-mutation.
   */
  it('TOGGLE', () => {
    // Initialize the test.
    const todo = {
      title: 'Hello World!',
      completed: false,
      id: 1,
    };
    const todo2 = {
      title: 'Hello World2!',
      completed: true,
      id: 2,
    };
    const state = {
      all: [todo, todo2],
    };

    // Apply mutation
    mutations.TOGGLE(state, todo);
    mutations.TOGGLE(state, todo2);

    // Assert result
    expect(state.all[0].completed);
    expect(state.all[0].id).to.equal(1);
    expect(!state.all[1].completed);
    expect(state.all[1].id).to.equal(2);
  });
});
