import Vue from 'vue';
import Vuex from 'vuex';
import todo from './modules/todo';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  /**
   * The modules being used in the Vuex store.
   */
  modules: {
    todo,
  },

  /**
   * If strict mode should be enabled.
   */
  strict: debug,
});
