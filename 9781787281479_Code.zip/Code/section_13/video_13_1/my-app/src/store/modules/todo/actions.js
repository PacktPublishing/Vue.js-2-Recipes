import * as types from './mutation-types';

export default {
  /**
   * Action which will add a new todo.
   *
   * @param {Function} commit  Will commit a mutation.
   * @param {*}        payload The payload being send to the mutation.
   */
  add({ commit }, payload) {
    setTimeout(() => {
      commit(types.ADD, payload)
    }, 100);
  },

  /**
   * Action which will remove a todo.
   *
   * @param {Function} commit  Will commit a mutation.
   * @param {*}        payload The payload being send to the mutation.
   */
  remove({ commit }, payload) {
    setTimeout(() => {
      commit(types.REMOVE, payload)
    }, 100);
  },

  /**
   * Action which will toggle a todo.
   *
   * @param {Function} commit  Will commit a mutation.
   * @param {*}        payload The payload being send to the mutation.
   */
  toggle({ commit }, payload) {
    setTimeout(() => {
      commit(types.TOGGLE, payload)
    }, 100);
  },
};
