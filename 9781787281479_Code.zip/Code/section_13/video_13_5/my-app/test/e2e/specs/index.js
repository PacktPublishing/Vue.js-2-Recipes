// For authoring Nightwatch tests, see
// http://nightwatchjs.org/guide#usage

module.exports = {
  'Can add todos'(browser) {
    const devServer = browser.globals.devServerURL;

    browser
      .url(devServer)
      .waitForElementVisible('#app', 5000)

      // Add the first todo
      .setValue('.card-body form input.form-control', 'Hello World 1!')
      .click('.card-body form button.btn.btn-dark')

      // Add the second todo
      .setValue('.card-body form input.form-control', 'Hello World 2!')
      .click('.card-body form button.btn.btn-dark')

      // The unfinished title should be visible.
      .expect.element('#unfinished-title').to.be.present.before(5000);

    browser
      // Check if the first todo has been added correctly
      .assert.visible('.list-group .list-group-item:nth-of-type(1)')
      .assert.containsText('.list-group-item:nth-of-type(1)', 'Hello World 1!')

      // Check if the second todo has been added correctly
      .assert.visible('.list-group .list-group-item:nth-of-type(2)')
      .assert.containsText('.list-group-item:nth-of-type(2)', 'Hello World 2!')
  },

  'Can toggle todo'(browser) {
    browser
      // Toggle the todo
      .click('.list-group-item-action:nth-of-type(1)')
      .expect.element('#finished-title').to.be.present.before(5000);

    browser
      .assert.containsText('.list-group-item.disabled', 'Hello World 1!');
  },

  'Can remove todo'(browser) {
    browser
      // Remove the unfinished todo
      .click('#unfinished-title + .list-group .list-group-item .btn-danger')
      .expect.element('#unfinished-title').to.not.be.present.before(5000);

    browser
      // Remove the finished todo
      .click('#finished-title + .list-group .list-group-item .btn-danger')
      .expect.element('#finished-title').to.not.be.present.before(5000);

    browser
      .expect.element('.list-group-item').to.not.be.present.before(5000);

    browser
      .end();
  }
};
