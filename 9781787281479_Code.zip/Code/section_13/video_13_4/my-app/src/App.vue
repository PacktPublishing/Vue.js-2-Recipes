<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-10">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Unit Testing the Getters from the Vuex Store
            </h4>
            <div class="card-body">
              <form @submit.prevent="addTodo">
                <div class="form-group">
                  <input
                    class="form-control"
                    v-model="todo"
                    placeholder="The title of the todo"
                  >
                </div>
                <div class="form-group">
                  <button class="btn btn-dark">
                    Add todo
                  </button>
                </div>
              </form>

              <div v-if="unfinishedTodos.length > 0">
                <hr />
                <h5>
                  Unfinished:
                </h5>
                <div class="list-group">
                  <v-todo
                    v-for="todo in unfinishedTodos"
                    :key="todo.id"
                    @toggle="toggleTodo(todo)"
                    @remove="removeTodo(todo)"
                  >
                    {{ todo.title }}
                  </v-todo>
                </div>
              </div>
              <div v-if="finishedTodos.length > 0">
                <hr />
                <h5>
                  Finished:
                </h5>
                <div class="list-group">
                  <v-todo
                    v-for="todo in finishedTodos"
                    :key="todo.id"
                    @toggle="toggleTodo(todo)"
                    @remove="removeTodo(todo)"
                    is-finished
                  >
                    {{ todo.title }}
                  </v-todo>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters, mapActions, mapMutations } from 'vuex';
  import VTodo from './components/Todo.vue';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The data this Vue instance can use.
     *
     * @returns {Object} The view model
     */
    data() {
      return {
        todo: '',
      };
    },

    /**
     * The computed properties this Vue instance can use.
     */
    computed: {
      ...mapGetters({
        finishedTodos: 'todo/finished',
        unfinishedTodos: 'todo/unfinished',
      })
    },

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      ...mapActions({
        removeTodo: 'todo/remove',
        toggleTodo: 'todo/toggle',
      }),

      /**
       * Used to add a new todo.
       */
      addTodo() {
        if (!this.todo) {
          return false;
        }

        this.$store.dispatch('todo/add', this.todo);

        this.todo = '';
      },
    },

    /**
     * The components this Vue instance can use.
     */
    components: {
      VTodo,
    },
  };
</script>
