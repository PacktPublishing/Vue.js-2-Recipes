import getters from '@/store/modules/todo/getters'

describe('getters', () => {
  // Set the state of the tests.
  const finishedTodos = [
    {
      title: 'Hello World! - 2',
      completed: true,
      id: 2
    },
    {
      title: 'Hello World! - 4',
      completed: true,
      id: 4
    }
  ];
  const unfinishedTodos = [
    {
      title: 'Hello World! - 1',
      completed: false,
      id: 1
    },
    {
      title: 'Hello World! - 3',
      completed: false,
      id: 3
    },
  ];
  const state = {
    all: finishedTodos.concat(unfinishedTodos)
  };

  /**
   * Unit Test which will test the finished-getter.
   */
  it('finished', () => {
    // Get the result from the getter
    const result = getters.finished(state);

    // Assert result
    expect(result).to.deep.equal(finishedTodos);
  });

  /**
   * Unit Test which will test the unfinished-getter.
   */
  it('unfinished', () => {
    // Get the result from the getter
    const result = getters.unfinished(state);

    // Assert result
    expect(result).to.deep.equal(unfinishedTodos);
  });
});
