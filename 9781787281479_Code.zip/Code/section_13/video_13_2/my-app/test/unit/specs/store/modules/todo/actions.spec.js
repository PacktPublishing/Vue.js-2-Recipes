import actions from '@/store/modules/todo/actions'
import types from '@/store/modules/todo/mutation-types'

const testAction = (action, payload, state, expectedMutations, done) => {
  let count = 0;

  // Mock commit
  const commit = (type, payload) => {
    const mutation = expectedMutations[count];

    try {
      expect(mutation.type).to.equal(type);
      if (payload) {
        expect(mutation.payload).to.deep.equal(payload);
      }
    } catch (error) {
      done(error);
    }

    count++;
    if (count >= expectedMutations.length) {
      done();
    }
  };

  // Call the action with mocked store and arguments
  action({ commit, state }, payload);

  // Check if no mutations should have been dispatched
  if (expectedMutations.length === 0) {
    expect(count).to.equal(0);
    done();
  }
};

describe('actions', () => {
  /**
   * Unit Test which will test the add-action.
   */
  it('add', done => {
    // Test the action.
    testAction(actions.add,
      'hello worlds!',
      { all: [] },
      [{ type: types.ADD, payload: 'hello worlds!' }],
      done);
  });

  /**
   * Unit Test which will test the remove-action.
   */
  it('remove', done => {
    // Initialize the test.
    const todo = {
      title: 'Hello World!',
      completed: false,
      id: 1,
    };

    // Test the action.
    testAction(actions.remove,
      todo,
      { all: [todo] },
      [{ type: types.REMOVE, payload: todo }],
      done);
  });

  /**
   * Unit Test which will test the toggle-action.
   */
  it('toggle', done => {
    // Initialize the test.
    const todo = {
      title: 'Hello World!',
      completed: false,
      id: 1,
    };

    // Test the action.
    testAction(actions.toggle,
      todo,
      { all: [todo] },
      [{ type: types.TOGGLE, payload: todo }],
      done);
  });
});
