<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark">
              Date
            </h4>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <input
                      class="form-control"
                      v-model="date.input"
                      placeholder="The date..."
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <input
                    class="form-control"
                    v-model="date.formatInput"
                    placeholder="The format that will be parsed..."
                  />
                </div>
                <div class="col-md-6">
                  <input
                    class="form-control"
                    v-model="date.formatOutput"
                    placeholder="The format that will be displayed..."
                  />
                </div>
              </div>
            </div>
            <div class="card-footer">
              {{ date.input | momentify(date) || 'The converted date...' }}
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark">
              Time
            </h4>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <input
                      class="form-control"
                      v-model="time.input"
                      placeholder="The time..."
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <input
                    class="form-control"
                    v-model="time.formatInput"
                    placeholder="The format that will be parsed..."
                  />
                </div>
                <div class="col-md-6">
                  <input
                    class="form-control"
                    v-model="time.formatOutput"
                    placeholder="The format that will be displayed..."
                  />
                </div>
              </div>
            </div>
            <div class="card-footer">
              {{ time.input | momentify(time) || 'The converted time...' }}
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark">
              Offset
            </h4>
            <div class="card-body">
              <div class="row">
                <div class="col col-md-12">
                  <div class="form-group">
                    <input
                      class="form-control"
                      v-model="offset.input"
                      placeholder="The date for the offset..."
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col col-md">
                  <input
                    class="form-control"
                    v-model="offset.formatInput"
                    placeholder="The format that will be parsed..."
                  />
                </div>
                <div class="col col-md">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input
                        class="form-check-input"
                        v-model="offset.offset"
                        type="checkbox"
                      >
                      Using offset?
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer">
              {{ offset.input | momentify(offset) || 'The offset for the date...' }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Moment from 'moment';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        /**
         * The data for the date.
         */
        date: {
          input: '',
          formatInput: 'MM-DD-YYYY',
          formatOutput: 'DD-MM-YYYY',
        },

        /**
         * The data for the time.
         */
        time: {
          input: '',
          formatInput: 'hh:mm:ss',
          formatOutput: 'hh:mm',
        },

        /**
         * The data for the offset.
         */
        offset: {
          input: '',
          formatInput: 'MM-DD-YYYY',
          offset: true,
        }
      };
    },

    /**
     * The filters that can be used on this Vue component.
     */
    filters: {
      /**
       * Filter used to transform a date to a momentJS date.
       *
       * @param {string|null|undefined} value        The input value.
       * @param {string}                formatInput  The format for the input.
       * @param {string}                formatOutput The format for the output.
       * @param {boolean}               offset       If the date should be displayed as an offset.
       *
       * @returns {string} The output value.
       */
      momentify(value, { formatInput, formatOutput, offset = false }) {
        if (!value) {
          return '';
        }

        let moment = Moment(value, formatInput);

        moment = offset ?
          moment.fromNow() :
          moment.format(formatOutput);

        return moment.toString();
      }
    }
  }
</script>
