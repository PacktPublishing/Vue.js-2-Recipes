<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h4>My Todo List ({{ unfinishedTodoItems.length }})</h4>
            </div>
            <div class="card-body">
              <form @submit.prevent="add()">
                <input
                  class="form-control"
                  v-model="newTodo"
                  placeholder="Enter a new todo..."
                >
              </form>
              <hr />
              <ul class="list-group">
                <li
                  class="list-group-item todo"
                  v-for="todo in unfinishedTodoItems"
                  @click="finish(todo)"
                  @click.shift="remove(todo)"
                >{{ todo.content }}</li>
              </ul>

              <hr />

              <ul class="list-group">
                <li
                  class="list-group-item disabled todo"
                  v-for="todo in finishedTodoItems"
                  @click="unfinish(todo)"
                  @click.shift="remove(todo)"
                >{{ todo.content }}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        /**
         * The todo items.
         */
        todoItems: [
          {
            done: false,
            content: 'Clean the house',
          },
          {
            done: false,
            content: 'Do the groceries',
          },
          {
            done: false,
            content: 'Wash my clothes',
          },
        ],

        /**
         * The todo that will be added.
         */
        newTodo: '',
      };
    },

    /**
     * The computed properties that are being used by the Vue component.
     */
    computed: {
      /**
       * Fill filter the todo items that are not.
       *
       * @returns {Array} The unfinished todo items.
       */
      unfinishedTodoItems() {
        return this.todoItems.filter(item => !item.done);
      },

      /**
       * Fill filter the todo items that are finished.
       *
       * @returns {Array} The finished todo items.
       */
      finishedTodoItems() {
        return this.todoItems.filter(item => item.done);
      },
    },

    /**
     * The methods that can be used by this Vue component.
     */
    methods: {
      /**
       * Method used to finish a given todo item.
       *
       * @param {Object} todo The given todo item.
       */
      finish(todo) {
        todo.done = true;
      },

      /**
       * Method used to un-finish a given todo item.
       *
       * @param {Object} todo The given todo item.
       */
      unfinish(todo) {
        todo.done = false;
      },

      /**
       * Method used to add a new todo item to the array of items.
       */
      add() {
        if (!this.newTodo) {
          return;
        }

        this.todoItems.push({
          content: this.newTodo,
          done: false,
        });

        this.newTodo = null;
      },

      /**
       * Method used to remove a todo item from the list of todo items.
       *
       * @param {Object} todo The given todo item.
       */
      remove(todo) {
        this.todoItems = this.todoItems.filter(item => item !== todo);
      }
    }
  }
</script>
<style>
  .todo {
    cursor: pointer;
  }
</style>
