<template>
  <div id="app">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card">
            <h4 class="card-header"
                :class="cardClasses"
            >
              Class binding
            </h4>
            <div class="card-body">
              <div class="form-group">
                <select
                  v-model="card.selectedStyling"
                  class="form-control"
                >
                  <option
                    v-for="style in card.contextualStyles"
                    :value="style"
                  >
                    {{ style.type | ucfirst }}
                  </option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <h4 class="card-header">
              Style binding
            </h4>
            <div class="card-body">
              <div class="form-group">
                <div class="input-group">
                  <input
                    class="form-control"
                    v-model="progress.width"
                    placeholder="The width of the process bar"
                  >
                  <span class="input-group-addon">%</span>
                </div>
              </div>
              <div class="form-group">
                <input
                  class="form-control"
                  v-model="progress.backgroundColor"
                  placeholder="The background-color of the process bar">
              </div>
            </div>
            <div class="card-footer">
              <div class="progress">
                <div
                  class="progress-bar"
                  :style="progressStyling"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        /**
         * The card.
         */
        card: {
          selectedStyling: {
            type: 'light',
            hasWhiteText: false,
          },
          contextualStyles: [
            { type: 'primary', hasWhiteText: true, },
            { type: 'secondary', hasWhiteText: true, },
            { type: 'success', hasWhiteText: true, },
            { type: 'danger', hasWhiteText: true, },
            { type: 'warning', hasWhiteText: true, },
            { type: 'info', hasWhiteText: true, },
            { type: 'light', hasWhiteText: false, },
            { type: 'dark', hasWhiteText: true, },
          ]
        },

        /**
         * The progress bar.
         */
        progress: {
          width: 50,
          backgroundColor: '#0af'
        },
      };
    },

    /**
     * The computed properties that are being used by the Vue component.
     */
    computed: {
      /**
       * The classes that should be applied to the card header.
       *
       * @returns {Array} The array of classes.
       */
      cardClasses() {
        const classes = [];

        if (!this.card.selectedStyling) {
          return classes;
        }

        classes.push(`bg-${this.card.selectedStyling.type}`);

        if (this.card.selectedStyling.hasWhiteText) {
          classes.push('text-white');
        }

        return classes;
      },

      /**
       * The styling that should be applied to the process bar.
       *
       * @returns {Object} The styling object.
       */
      progressStyling() {
        return {
          width: `${this.progress.width}%`,
          backgroundColor: this.progress.backgroundColor,
        };
      }
    },

    /**
     * The filters that can be used on this Vue component.
     */
    filters: {
      /**
       * Will uppercase the first character of a given string.
       *
       * @param {string|null|undefined} value The given string.
       *
       * @returns {string} The transformed string.
       */
      ucfirst(value) {
        if (!value) {
          return '';
        }

        return value.charAt(0).toUpperCase() + value.slice(1);
      }
    }
  }
</script>
