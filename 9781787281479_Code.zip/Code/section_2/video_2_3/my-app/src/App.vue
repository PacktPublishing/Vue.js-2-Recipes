<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card">
            <h4 class="card-header">
              Currency
            </h4>
            <div class="card-body">
              <input
                class="form-control"
                v-model="amount"
                placeholder="The amount of money..."
              />
              <hr />
              <div class="form-group">
                <input
                  class="form-control"
                  placeholder="The amount converted to currency..."
                  :value="amount | currency" readonly
                >
              </div>
              <div class="form-group">
                <input
                  class="form-control"
                  placeholder="The currency with a different symbol..."
                  :value="amount | currency({ symbol: '€' })" readonly
                >
              </div>
              <div class="form-group">
                <input
                  class="form-control"
                  placeholder="The currency with a different precision..."
                  :value="amount | currency({ precision: 4 })" readonly
                >
              </div>
              <div class="form-group">
                <input
                  class="form-control"
                  placeholder="The currency with a different thousand symbol..."
                  :value="amount | currency({ thousand: '.' })" readonly
                >
              </div>
              <div class="form-group">
                <input
                  class="form-control"
                  placeholder="The currency with a different decimal symbol..."
                  :value="amount | currency({ decimal: ',' })" readonly
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { formatMoney } from 'accounting-js';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        /**
         * The amount being used for the filter.
         */
        amount: '',
      };
    },

    /**
     * The filters that can be used on this Vue component.
     */
    filters: {
      /**
       * The currency filter which uses the accounting JS package.
       *
       * @param {String} value   The value.
       * @param {Object} options The extra options for accounting JS.
       *
       * @returns {String} The formatted money.
       */
      currency(value, options) {
        if (!value) {
          return '';
        }

        return formatMoney(value, options);
      },
    }
  }
</script>
