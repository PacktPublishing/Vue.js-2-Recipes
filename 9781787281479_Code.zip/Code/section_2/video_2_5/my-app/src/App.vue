<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark ">v-if, v-else, v-else-if</h4>
            <div class="card-body">
              <pre>{{ vIf }}</pre>
              <button
                class="btn btn-primary"
                @click="toggle('vIf', 'booleanOne')"
              >
                Toggle boolean #1
              </button>
              <button
                class="btn btn-primary"
                @click="toggle('vIf', 'booleanTwo')"
              >
                Toggle boolean #2
              </button>
            </div>
            <div class="card-footer">
              <div v-if="vIf.booleanOne">
                Show if boolean #1 is true and/or boolean #2 is true.
              </div>
              <div v-else-if="vIf.booleanTwo">
                Shown if boolean #1 is false and boolean #2 is true.
              </div>
              <div v-else>
                Shown if boolean #1 & #2 are both false.
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark ">v-show</h4>
            <div class="card-body">
              <pre>{{ vShow }}</pre>
              <button
                class="btn btn-primary"
                @click="toggle('vShow', 'booleanOne')"
              >
                Toggle boolean #1
              </button>
            </div>
            <div class="card-footer">
              <div v-show="vShow.booleanOne">
                Shown if boolean #1 is true.
              </div>
              <div v-show="!vShow.booleanOne">
                Shown if boolean #1 is false.
              </div>
            </div>
          </div>
        </div>
      </div>
      <br />
      <div class="row">
        <div class="col">
          <div class="card">
            <h4 class="card-header text-white bg-dark ">Object example</h4>
            <div class="card-body">
              <pre>{{ object }}</pre>
              <hr />
              <div v-if="object">
                <div v-if="object.propertyOne">
                  {{ object.propertyOne }}
                </div>
                <div v-if="object.propertyTwo">
                  <div v-if="object.propertyTwo.propertyTwoOne">
                    {{ object.propertyTwo.propertyTwoOne }}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        // v-if, v-else-if & v-else
        vIf: {
          booleanOne: true,
          booleanTwo: true,
        },

        // v-show
        vShow: {
          booleanOne: true,
        },

        object: {
          propertyOne: 'Present',
          propertyTwo: {
            propertyTwoOne: 'Missing'
          },
        }
      };
    },

    /**
     * The methods that can be used by this Vue component.
     */
    methods: {
      toggle(object, boolean) {
        this[object][boolean] = !this[object][boolean];
      },
    }
  }
</script>
