<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="card">
            <div class="card-header">
              <h4>My Users ({{ users.length }})</h4>
            </div>
            <div class="card-body">
              <form @submit.prevent="add()">
                <div class="form-group">
                  <input
                    class="form-control"
                    v-model="newUser.username"
                    placeholder="Enter a username..."
                  >
                </div>
                <div class="form-group">
                  <input
                    type="email"
                    class="form-control"
                    v-model="newUser.email"
                    placeholder="Enter a email..."
                  >
                </div>
                <div class="form-group">
                  <button class="btn btn-primary">
                    Add user
                  </button>
                </div>
              </form>
              <hr />
              <div class="form-group">
                <button
                  class="btn btn-outline-primary"
                  @click="sortBy('username')"
                >
                  Sort by username
                </button>
                <button
                  class="btn btn-outline-primary"
                  @click="sortBy('email')"
                >
                  Sort by email
                </button>
              </div>
              <ul class="list-group">
                <li
                  class="list-group-item"
                  v-for="user in sortedUsers"
                >{{ user.username }}, {{ user.email }}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The view-model that's being used by this Vue component.
     *
     * @returns {Object} The view-model.
     */
    data() {
      return {
        /**
         * The users.
         */
        users: [
          {
            username: 'john.doe',
            email: 'john@doe.com',
          },
          {
            username: 'admin',
            email: 'test@admin.com',
          },
          {
            username: 'foo',
            email: 'bar@foo.com',
          },
          {
            username: 'petervmeijgaard',
            email: 'peter@test.com',
          },
        ],

        /**
         * The new item that will be added.
         */
        newUser: {
          username: '',
          email: '',
        },

        /**
         * The sorting of the items.
         */
        sortingKey: null,
      };
    },

    /**
     * The computed properties that are being used by the Vue component.
     */
    computed: {
      /**
       * Computed property which will return the sorted items.
       *
       * @returns {Array} The sorted items.
       */
      sortedUsers() {
        if (!this.sortingKey) {
          return this.users;
        }

        return this.users.concat().sort((userA, userB) => {
          if (userA[this.sortingKey] > userB[this.sortingKey]) {
            return 1;
          }

          if (userA[this.sortingKey] < userB[this.sortingKey]) {
            return -1;
          }

          return 0;
        });
      },
    },

    /**
     * The methods that can be used by this Vue component.
     */
    methods: {
      /**
       * Method used to add a new item to the list of items.
       */
      add() {
        if (!this.newUser.username || !this.newUser.email) {
          return;
        }

        this.users.push(this.newUser);

        this.newUser = {
          username: '',
          email: '',
        };
      },

      /**
       * Method used to set the sorting of the list of items.
       *
       * @param {String} key The sorting key.
       */
      sortBy(key) {
        this.sortingKey = key;
      }
    }
  }
</script>
