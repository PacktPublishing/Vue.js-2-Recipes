export default {
  /**
   * The array of alert messages.
   */
  alertMessages: [],
};
