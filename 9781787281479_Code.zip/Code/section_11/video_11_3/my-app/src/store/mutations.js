export default {
  /**
   * The mutation which will add an alert to the alert messages.
   *
   * @param {Object} state The state.
   * @param {Object} alert The alert being added to the alert messages.
   */
  addAlert(state, alert) {
    state.alertMessages.push(alert);
  },

  /**
   * The mutation which will remove an alert message.
   *
   * @param {Object} state The state.
   * @param {Object} alert The alert being removed from the alert messages.
   */
  removeAlert(state, alert) {
    state.alertMessages = state.alertMessages.filter(item => item !== alert);
  },
};
