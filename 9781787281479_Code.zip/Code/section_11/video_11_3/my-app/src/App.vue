<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-6">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Accessing Store Data in Components
            </h4>
            <div class="card-body">
              <form @submit.prevent="addAlert(alert)">
                <div class="form-group">
                  <label for="alert.message">
                    The alert message
                  </label>
                  <input
                    id="alert.message"
                    class="form-control"
                    placeholder="The message"
                    v-model="alert.message"
                  >
                </div>
                <div class="form-group">
                  <label for="alert.style">
                    The alert style
                  </label>
                  <select
                    id="alert.style"
                    class="form-control"
                    v-model="alert.type"
                  >
                    <option
                      v-for="style in styles"
                      :value="style"
                    >
                      {{ style | ucfirst }}
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <button class="btn btn-dark">
                    Add alert
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container fixed-bottom">
      <div class="row justify-content-end">
        <div class="col col-4">
          <v-alert
            v-for="alert in alertMessages"
            :key="alert.message"
            :type="alert.type"
            @close="removeAlert(alert)"
          >
            {{ alert.message }}
          </v-alert>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import VAlert from './components/Alert';
  import { mapState } from 'vuex';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The data this Vue instance can use.
     *
     * @return {Object} The view-model.
     */
    data() {
      return {
        alert: {
          message: '',
          type: 'primary'
        },
        styles: [
          'primary',
          'dark',
          'success',
          'danger',
          'warning',
          'info'
        ],
      }
    },

    /**
     * The computed properties this Vue instance can use.
     */
    computed: {
      ...mapState([
        // this.alertMessages = this.$store.state.alertMessages
        'alertMessages'
      ]),
    },

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      /**
       * Used to add an alert.
       * Will commit the `addAlert`-mutation.
       *
       * @param {Object} alert The alert to be added.
       */
      addAlert(alert) {
        if (!alert.message) {
          return;
        }

        this.$store.commit('addAlert', Object.assign({}, alert));

        alert.message = '';
      },

      /**
       * Used to remove an alert.
       * Will commit the `removeAlert`-mutation.
       *
       * @param {Object} alert The alert to be removed.
       */
      removeAlert(alert) {
        this.$store.commit('removeAlert', alert);
      }
    },

    /**
     * The filters that can be used by this Vue instance.
     */
    filters: {
      /**
       * Will uppercase the first character.
       *
       * @param {String|undefined} value The value to be transformed.
       *
       * @return {String} The
       */
      ucfirst(value) {
        if (!value) {
          return '';
        }

        return value.charAt(0).toUpperCase() + value.slice(1);
      }
    },

    /**
     * The components that this Vue instance can use.
     */
    components: {
      VAlert,
    }
  }
</script>
