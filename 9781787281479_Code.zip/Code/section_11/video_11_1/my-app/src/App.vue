<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-6">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Adding Vuex to your Application
            </h4>
            <div class="card-body">
              <div class="btn-group">
                <button
                  @click="decrement"
                  class="btn btn-dark"
                >-</button>
                <button
                  @click="increment"
                  class="btn btn-dark"
                >+</button>
              </div>
              <hr />
              The counter: {{ $store.state.count }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      /**
       * Method used to decrement the counter.
       * Will commit the `decrement`-mutation.
       */
      decrement() {
        this.$store.commit('decrement');
      },

      /**
       * Method used to increment the counter.
       * Will commit the `increment`-mutation.
       */
      increment() {
        this.$store.commit('increment');
      },
    }
  }
</script>
