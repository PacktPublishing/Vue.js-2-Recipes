import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  /**
   * The state of the Vuex-store.
   */
  state: {
    count: 0,
  },

  /**
   * The mutations that this store can use.
   */
  mutations: {
    /**
     * Will increment the counter.
     *
     * @param {Object} state The state of the application.
     */
    increment(state) {
      state.count++;
    },

    /**
     * Will decrement the counter.
     *
     * @param {Object} state The state of the application.
     */
    decrement(state) {
      if(state.count === 0) {
        return;
      }

      state.count--;
    }
  },

  /**
   * If strict mode should be enabled.
   */
  strict: debug,

  /**
   * Plugins used in the store.
   */
  plugins: [],
});
