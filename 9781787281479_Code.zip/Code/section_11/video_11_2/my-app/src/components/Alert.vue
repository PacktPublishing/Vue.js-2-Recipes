<template>
  <div :class="classNames">
    <button
      type="button"
      class="close"
      @click="close"
    >
      <span>&times;</span>
    </button>
    <slot>{{ content }}</slot>
  </div>
</template>
<script>
  export default {
    /**
     * The properties that are used by this component.
     */
    props: {
      /**
       * The content to be displayed.
       */
      content: {
        type: String,
        required: false,
      },

      /**
       * The contextual type.
       */
      type: {
        type: String,
        required: false,
      },
    },

    /**
     * The computed properties that can be used by this component.
     */
    computed: {
      /**
       * Will return an array of class names.
       *
       * @return {Array} The class names.
       */
      classNames() {
        const classNames = ['alert'];

        if (this.type) {
          classNames.push(`alert-${this.type}`);
        }

        return classNames;
      }
    },

    /**
     * The methods that are used by this component.
     */
    methods: {
      /**
       * Will emit the close-event.
       */
      close() {
        this.$emit('close');
      }
    }
  }
</script>
