import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  /**
   * The state of the application.
   */
  state: {
    /**
     * The array of alert messages.
     */
    alertMessages: [],
  },

  /**
   * The mutations that the store can commit.
   */
  mutations: {
    /**
     * The mutation which will add an alert to the alert messages.
     *
     * @param {Object} state The state.
     * @param {Object} alert The alert being added to the alert messages.
     */
    addAlert(state, alert) {
      state.alertMessages.push(alert);
    },

    /**
     * The mutation which will remove an alert message.
     *
     * @param {Object} state The state.
     * @param {Object} alert The alert being removed from the alert messages.
     */
    removeAlert(state, alert) {
      state.alertMessages = state.alertMessages.filter(item => item !== alert);
    },
  },

  /**
   * If strict mode should be enabled.
   */
  strict: debug,
});
