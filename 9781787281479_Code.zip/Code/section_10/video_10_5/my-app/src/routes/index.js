export default [
  {
    path: '/home',
    name: 'home',
    component: () => import('@/pages/Home'),
  },

  {
    path: '/account',
    name: 'account',
    component: () => import('@/pages/Account'),
  },

  {
    path: '/',
    redirect: '/home',
  },

  {
    path: '/*',
    redirect: '/home',
  },
];
