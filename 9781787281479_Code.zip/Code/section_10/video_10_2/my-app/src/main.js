import Vue from 'vue'
import App from './App'

import 'bootstrap/dist/css/bootstrap.css'

// Setting up Axios
import Axios from 'axios';

Axios.defaults.baseURL = 'https://jsonplaceholder.typicode.com';
Axios.defaults.headers.common.Accept = 'application/json';

Vue.$http = Axios;
Object.defineProperty(Vue.prototype, '$http', {
  get() {
    return Axios;
  }
});

// Setting up Vue Router.
import VueRouter from 'vue-router'
import routes from '@/routes'

Vue.use(VueRouter);

export const router = new VueRouter({
  routes,
});

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
});
