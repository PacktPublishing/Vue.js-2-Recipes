<template>
  <div>
    <div
      class="card"
      v-if="post"
    >
      <h4 class="card-header bg-dark text-white">
        {{ post.title }}
      </h4>
      <div class="card-body">
        {{ post.body }}
      </div>
      <div class="card-footer">
        <router-link :to="{ name: 'posts.index' }">
          Go back...
        </router-link>
      </div>
    </div>
    <div v-else>
      Loading...
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The properties being used by this page.
     */
    props: {
      /**
       * The ID of the post.
       */
      id: {
        type: [String, Number],
        required: true,
      }
    },

    /**
     * The data this page can use.
     *
     * @return {Object} The view-model.
     */
    data() {
      return {
        post: null,
      };
    },

    /**
     * The methods that this page can use.
     */
    methods: {
      /**
       * Method used to find a post.
       */
      findPost() {
        this.$http
          .get(`posts/${this.id}`)
          .then(({ data }) => {
            this.post = data;
          })
      }
    },

    /**
     * Watchers that this page can use.
     */
    watch: {
      /**
       * Watch the post id on change.
       */
      id() {
        this.findPost();
      },
    },

    /**
     * Will be called once the page has been loaded.
     */
    created() {
      this.findPost();
    }
  };
</script>
