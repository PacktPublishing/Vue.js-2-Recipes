<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Posts overview page
    </h4>
    <div class="card-body">
      <div class="list-group">
        <router-link
          v-for="post in posts"
          class="list-group-item list-group-item-action"
          :to="{ name: 'posts.show', params: { id: post.id } }"
          :key="post.id"
        >
          {{ post.title }}
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The data this page can use.
     *
     * @return {Object} The view-model.
     */
    data() {
      return {
        posts: [],
      };
    },

    /**
     * Methods that this page can use.
     */
    methods: {
      /**
       * Method used to fetch all the posts.
       */
      fetchPosts() {
        this.$http
          .get('posts')
          .then(({ data }) => {
            this.posts = data;
          })
      }
    },

    /**
     * Will be called once the page has been mounted.
     */
    created() {
      this.fetchPosts();
    }
  };
</script>
