<template>
  <div id="app">
    <div class="jumbotron">
      <h1>Using Route Parameters</h1>
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-6">
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',
  }
</script>
