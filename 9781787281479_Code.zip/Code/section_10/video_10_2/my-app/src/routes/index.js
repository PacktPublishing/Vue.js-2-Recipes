export default [
  {
    path: '/posts',
    name: 'posts.index',
    component: () => import('@/pages/posts/Index'),
  },

  {
    path: '/posts/:id',
    name: 'posts.show',
    component: () => import('@/pages/posts/Show'),

    // Set the props-property to true to send parameters as properties.
    props: true,
  },

  {
    path: '/',
    redirect: '/posts',
  },

  {
    path: '/*',
    redirect: '/posts',
  },
];
