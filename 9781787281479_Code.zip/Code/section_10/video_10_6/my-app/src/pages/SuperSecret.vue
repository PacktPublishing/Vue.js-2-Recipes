<template>
  <div class="card mb-4">
    <img class="card-img" :src="require('@/assets/super_secret.gif')">
    <div class="card-body">
      <h4 class="card-title">
        Super Secret Page
      </h4>
      <p class="card-text">
        Nothing to see here, moving on...
      </p>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'super-secret-page',
  };
</script>
