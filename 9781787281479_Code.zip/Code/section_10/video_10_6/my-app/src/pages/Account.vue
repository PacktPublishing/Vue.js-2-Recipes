<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Account Page
    </h4>
    <div class="card-body">
      <dl>
        <dt>
          First name
        </dt>
        <dd>
          John
        </dd>
        <dt>
          Last name
        </dt>
        <dd>
          Doe
        </dd>
        <dt>
          Biography
        </dt>
        <dd>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit.
          Aperiam at atque deleniti dolores eaque eveniet facere harum
          in incidunt ipsum magnam, necessitatibus non, nostrum quaerat,
          qui quod ratione sit sunt.
        </dd>
      </dl>
    </div>
    <div class="card-footer">
      <router-link :to="{ name: 'home'}">
        Go to home page!
      </router-link>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'account-page',
  };
</script>
