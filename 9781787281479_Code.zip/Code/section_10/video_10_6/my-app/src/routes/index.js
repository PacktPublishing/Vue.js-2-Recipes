export default [
  {
    path: '/home',
    name: 'home',
    component: () => import('@/pages/Home'),

    meta: {
      auth: false,
    }
  },

  {
    path: '/account',
    name: 'account',
    component: () => import('@/pages/Account'),

    meta: {
      auth: true,
    }
  },

  {
    path: '/super-secret',
    name: 'super-secret',
    component: () => import('@/pages/SuperSecret'),

    meta: {
      auth: true,
    }
  },

  {
    path: '/',
    redirect: '/home',
  },

  {
    path: '/*',
    redirect: '/home',
  },
];
