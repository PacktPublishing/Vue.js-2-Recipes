<template>
  <div id="app">
    <div class="jumbotron">
      <h1>Developing Nested Routes</h1>
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-6">
          <router-link :to="{ name: 'home' }">Home</router-link> -
          <router-link :to="{ name: 'account' }">Account</router-link> -
          <router-link :to="{ name: 'super-secret' }">Super Secret</router-link>
          <hr />
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',
  }
</script>
