import Vue from 'vue'
import App from './App'

import 'bootstrap/dist/css/bootstrap.css'

// Setting up Vue Router.
import VueRouter from 'vue-router'
import routes from '@/routes'

Vue.use(VueRouter);

export const router = new VueRouter({
  routes,
});

// If the user is logged in
const userIsLoggedIn = true;

// Vue Router beforeEach navigation guard
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.auth) && !userIsLoggedIn) {
    alert('Sorry, you are not allowed to view this page...');

    next({
      name: 'home',
    });
  } else {
    next();
  }
});
Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
});
