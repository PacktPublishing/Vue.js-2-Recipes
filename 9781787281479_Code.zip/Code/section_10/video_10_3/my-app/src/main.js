import Vue from 'vue'
import App from './App'

import 'bootstrap/dist/css/bootstrap.css'

// Setting up Vue Router.
import VueRouter from 'vue-router'
import routes from '@/routes'

Vue.use(VueRouter);

export const router = new VueRouter({
  routes,
});

// Vue Router beforeEach navigation guard
router.beforeEach((to, from, next) => {
  console.log('<before-each>');
  console.log('To: ', to);
  console.log('From: ', from);
  console.log('</before-each>');
  next();

});

// Vue Router afterEach navigation guard
router.afterEach((to, from ) =>{
  console.log('<after-each>');
  console.log('To: ', to);
  console.log('From: ', from);
  console.log('</after-each>');
});

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
});
