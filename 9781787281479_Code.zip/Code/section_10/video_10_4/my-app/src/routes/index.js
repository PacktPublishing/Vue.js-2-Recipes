export default [
  {
    path: '/home',
    name: 'home',
    component: () => import('@/pages/Home'),
  },

  {
    path: '/account',
    name: 'account',
    component: () => import('@/pages/Account'),
    redirect: '/account/information',
    children: [
      {
        path: 'information',
        name: 'account.information',
        component: () => import('@/pages/Account/Information'),
      },
      {
        path: 'following',
        name: 'account.following',
        component: () => import('@/pages/Account/Following'),
      },
      {
        path: 'posts',
        name: 'account.posts',
        component: () => import('@/pages/Account/Posts'),
      },
    ],
  },

  {
    path: '/',
    redirect: '/home',
  },

  {
    path: '/*',
    redirect: '/home',
  },
];
