<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Account Page
    </h4>
    <div class="card-body">
      <router-link :to="{ name: 'account.information' }">
        Information
      </router-link>
      -
      <router-link :to="{ name: 'account.following' }">
        Following
      </router-link>
      -
      <router-link :to="{ name: 'account.posts' }">
        Posts
      </router-link>
      <hr />
      <router-view></router-view>
    </div>
    <div class="card-footer">
      <router-link :to="{ name: 'home'}">
        Go to home page!
      </router-link>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'account-page',
  };
</script>
