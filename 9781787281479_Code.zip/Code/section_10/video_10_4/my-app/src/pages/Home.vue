<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Home Page
    </h4>
    <div class="card-body">
      {{ helloMessage }}
    </div>
    <div class="card-footer">
      <router-link :to="{ name: 'account'}">
        Go to account page!
      </router-link>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'home-page',

    /**
     * The data the page can use.
     *
     * @return {Object} The view-model of the page.
     */
    data() {
      return {
        helloMessage: 'Hello from the home page!',
      }
    }
  };
</script>
