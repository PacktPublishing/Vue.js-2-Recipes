<template>
  <div class="list-group">
    <div class="list-group-item">
      Vue is awesome!
    </div>
    <div class="list-group-item">
      Hello World!
    </div>
    <div class="list-group-item">
      Foo Bar
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'account-posts-page',
  };
</script>
