<template>
  <div class="list-group">
    <div class="list-group-item">
      @petervmeijgaard
    </div>
    <div class="list-group-item">
      @packt
    </div>
    <div class="list-group-item">
      @youyuxi
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'account-following-page',
  };
</script>
