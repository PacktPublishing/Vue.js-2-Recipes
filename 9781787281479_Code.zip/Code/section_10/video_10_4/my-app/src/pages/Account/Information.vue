<template>
  <dl>
    <dt>
      First name
    </dt>
    <dd>
      John
    </dd>
    <dt>
      Last name
    </dt>
    <dd>
      Doe
    </dd>
    <dt>
      Biography
    </dt>
    <dd>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      Aperiam at atque deleniti dolores eaque eveniet facere harum
      in incidunt ipsum magnam, necessitatibus non, nostrum quaerat,
      qui quod ratione sit sunt.
    </dd>
  </dl>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'account-information-page',
  }
</script>
