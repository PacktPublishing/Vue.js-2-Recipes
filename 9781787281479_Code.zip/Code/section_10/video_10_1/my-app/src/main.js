import Vue from 'vue'
import App from './App'
import VueRouter from 'vue-router'
import routes from '@/routes'
import 'bootstrap/dist/css/bootstrap.css'

// Tell Vue to use Vue Router.
Vue.use(VueRouter);

// Create a new Vue Router instance.
export const router = new VueRouter({
  routes,
});

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',

  // Bind Vue Router to our Vue instance.
  router,

  render: h => h(App)
});
