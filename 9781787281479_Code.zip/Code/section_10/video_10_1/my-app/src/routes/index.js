export default [
  {
    path: '/home',
    name: 'home',
    component: () => import('@/pages/Home'),
  },

  {
    path: '/contact',
    name: 'contact',
    component: () => import('@/pages/Contact'),
  },

  {
    path: '/',
    redirect: '/home',
  },

  {
    path: '/*',
    redirect: '/home',
  },
];
