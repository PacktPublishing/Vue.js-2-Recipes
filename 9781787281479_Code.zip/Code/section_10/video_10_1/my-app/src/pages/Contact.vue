<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Contact Page
    </h4>
    <div class="card-body">
      {{ helloMessage }}
    </div>
    <div class="card-footer">
      <router-link :to="{ name: 'home'}">
        Go to home page!
      </router-link>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'contact-page',

    /**
     * The data the page can use.
     *
     * @return {Object} The view-model of the page.
     */
    data() {
      return {
        helloMessage: 'Hello from the contact page!',
      }
    }
  };
</script>
