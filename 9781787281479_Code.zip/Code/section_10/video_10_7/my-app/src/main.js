import Vue from 'vue'
import App from './App'

import 'bootstrap/dist/css/bootstrap.css'

// Setting up Vue Router.
import VueRouter from 'vue-router'
import routes from '@/routes'

Vue.use(VueRouter);

export const router = new VueRouter({
  routes,
  linkActiveClass: 'active',
});

import state from './state';

if(localStorage.getItem('isLoggedIn') === '1') {
  state.isLoggedIn = true;
}

// Vue Router beforeEach navigation guard
router.beforeEach((to, from, next) => {
  if (to.matched.some(record => record.meta.auth) && !state.isLoggedIn) {
    alert('Sorry, you are not allowed to view this page...');

    next({
      name: 'login',
    });
  } else if (to.matched.some(record => record.meta.guest) && state.isLoggedIn) {
    alert('Sorry, you cannot be logged in to view this page...');

    next({
      name: 'home',
    });
  } else {
    next();
  }
});
Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
});
