/**
 * The shared state of the application.
 */
export default {
  isLoggedIn: false,
};
