<template>
  <div id="app">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
          <router-link
            :to="{ name: 'home' }"
            class="nav-item"
            tag="li"
          >
            <a class="nav-link">
              Home
            </a>
          </router-link>

          <router-link
            v-if="shared.isLoggedIn"
            :to="{ name: 'account' }"
            class="nav-item"
            tag="li"
          >
            <a class="nav-link">
              Account
            </a>
          </router-link>

          <router-link
            v-if="shared.isLoggedIn"
            :to="{ name: 'super-secret' }"
            class="nav-item"
            tag="li"
          >
            <a class="nav-link">
              Super secret
            </a>
          </router-link>
        </ul>
        <div class="my-2 my-lg-0">
          <a
            @click.prevent="logout"
            href="#"
            class="btn btn-light"
            v-if="shared.isLoggedIn"
          >
            Logout
          </a>
          <router-link
            class="btn btn-light"
            v-else
            :to="{ name: 'login' }"
          >
            Login
          </router-link>
        </div>
      </div>
    </nav>
    <div class="container mt-4">
      <div class="row justify-content-center">
        <div class="col col-6">
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import shared from '@/state';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The data being used on this Vue instance.
     *
     * @return {Object} The view-model.
     */
    data() {
      return {
        shared,
      };
    },

    /**
     * The methods being used on this Vue intance.
     */
    methods: {
      /**
       * Used to logout the user.
       */
      logout() {
        this.shared.isLoggedIn = false;
        localStorage.setItem('isLoggedIn', '0');

        this.$router.push({
          name: 'login',
        });
      },
    },
  };
</script>
