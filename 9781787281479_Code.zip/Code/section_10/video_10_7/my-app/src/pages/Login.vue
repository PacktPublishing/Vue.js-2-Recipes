<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Login
    </h4>
    <div class="card-body">
      <form @submit.prevent="login(user)">
        <div class="form-group">
          <input
            class="form-control"
            v-model="user.email"
            placeholder="Email"
          >
        </div>
        <div class="form-group">
          <input
            class="form-control"
            type="password"
            v-model="user.password"
            placeholder="Password"
          >
        </div>
        <div class="form-group">
          <button class="btn btn-outline-dark">
            Login
          </button>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
  import shared from '@/state';

  export default {
    /**
     * The data being used by the page.
     *
     * @return {Object} The view-model.
     */
    data() {
      return {
        shared,
        user: {
          email: '',
          password: '',
        },
      };
    },

    /**
     * The methods being used by the page.
     */
    methods: {
      /**
       * Used to login the user.
       *
       * @param {Object} user The user being loggedin
       */
      login(user) {
        if(!user.email || !user.password) {
          return;
        }

        this.shared.isLoggedIn = true;
        localStorage.setItem('isLoggedIn', '1');

        this.$router.push({
          name: 'home',
        });
      }
    }
  };
</script>
