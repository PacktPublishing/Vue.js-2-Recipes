import Vue from 'vue';

export default {
  /**
   * Action to fetch the todos.
   *
   * @param {Object} context The context of the store.
   */
  fetchTodos(context) {
    Vue.$http.get('todos')
      .then(({ data }) => {
        context.commit('fetchTodos', data);
      })
      .catch(() => {
        console.log('Whoops! Something went wrong...');
      });
  },
}
