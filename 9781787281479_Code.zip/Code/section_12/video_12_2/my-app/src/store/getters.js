export default {
  /**
   * Getter for the finished todos.
   *
   * @param {Object} state The current state.
   *
   * @return {Array} The array of finished todos.
   */
  finishedTodos: state => state.todos.filter(todo => todo.completed),

  /**
   * Getter for the unfinished todos.
   *
   * @param {Object} state The current state.
   *
   * @return {Array} The array of unfinished todos.
   */
  unfinishedTodos: state => state.todos.filter(todo => !todo.completed),
};
