<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-10">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Managing your Application’s State with Vuex
            </h4>
            <div class="card-body">
              <div class="row">
                <div class="col col-6">
                  <h5>Unfinished todos</h5>
                  <div class="list-group">
                    <div
                      class="list-group-item"

                      v-for="todo in unfinishedTodos"
                      :key="todo.id"
                    >{{ todo.title }}</div>
                  </div>
                </div>
                <div class="col col-6">
                  <h5>Finished todos</h5>
                  <div class="list-group">
                    <div
                      class="list-group-item disabled"
                      v-for="todo in finishedTodos"
                      :key="todo.id"
                    >{{ todo.title }}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      /**
       * Used to fetch all the todos from the API.
       * Will dispatch the `fetchTodos`-action.
       */
      fetchTodos() {
        this.$store.dispatch('fetchTodos');
      },
    },

    /**
     * The computed properties this Vue instance can use.
     */
    computed: {
      ...mapGetters([
        // this.finishedTodos = $store.getters.finishedTodos
        'finishedTodos',

        // this.unfinishedTodos = $store.getters.unfinishedTodos
        'unfinishedTodos',
      ])
    },

    /**
     * Fired when the Vue instance is ready.
     */
    created() {
      this.fetchTodos();
    }
  }
</script>
