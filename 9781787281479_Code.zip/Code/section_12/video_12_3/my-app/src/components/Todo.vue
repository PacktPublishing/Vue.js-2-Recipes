<template>
  <div
    class="list-group-item list-group-item-action"
    :class="{ 'disabled': isFinished }"
    @click="toggle"
  >
    <div class="d-flex align-items-center justify-content-between">
      <div>
        <slot>{{ content }}</slot>
      </div>
      <button
        class="btn btn-danger"
        @click="remove"
      >Remove</button>
    </div>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the component.
     */
    name: 'todo',

    /**
     * The props this component can use.
     */
    props: {
      /**
       * The content to be displayed.
       */
      content: {
        required: false,
        type: String,
      },

      /**
       * If the todo item is finished.
       */
      isFinished: {
        required: false,
        type: Boolean,
      },
    },

    /**
     * The methods this component can use.
     */
    methods: {
      /**
       * Will emit the remove event.
       */
      remove() {
        this.$emit('remove');
      },

      /**
       * Will emit the toggle event.
       */
      toggle() {
        this.$emit('toggle');
      },
    }
  };
</script>
