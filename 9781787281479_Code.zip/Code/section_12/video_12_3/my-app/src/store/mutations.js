import {
  ADD_TODO,
  REMOVE_TODO,
  TOGGLE_TODO,
} from './mutation-types';

export default {
  /**
   * Mutation which will add a new todo to the array of todos.
   *
   * @param {Object} state The state of the application.
   * @param {String} todo  The new todo item.
   */
  [ADD_TODO](state, todo) {
    // Create a copy of the todos array and grab the last item.
    const lastTodo = state.todos.slice(-1).pop();

    state.todos.push({
      title: todo,
      completed: false,
      id: lastTodo ? lastTodo.id + 1 : 1,
    });
  },

  /**
   * Mutation which will remove a todo.
   *
   * @param {Object} state The state of the application.
   * @param {Object} todo  The todo to be removed.
   */
  [REMOVE_TODO](state, todo) {
    state.todos = state.todos.filter(item => item !== todo);
  },

  /**
   * Mutation which will toggle a todo.
   *
   * @param {Object} state The state of the application.
   * @param {Object} todo  The todo to be toggled.
   */
  [TOGGLE_TODO](state, todo) {
    const foundTodo = state.todos.find(item => item === todo);

    foundTodo.completed = !foundTodo.completed;
  },
}
