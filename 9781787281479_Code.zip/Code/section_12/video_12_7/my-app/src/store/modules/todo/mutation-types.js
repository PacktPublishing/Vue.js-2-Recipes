export const ADD = 'ADD';
export const UPDATE = 'UPDATE';
export const REMOVE = 'REMOVE';
export const TOGGLE_EDIT = 'TOGGLE_EDIT';

export default {
  ADD,
  UPDATE,
  REMOVE,
  TOGGLE_EDIT,
};
