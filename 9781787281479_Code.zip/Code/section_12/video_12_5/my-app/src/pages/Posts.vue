<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Posts Page
    </h4>
    <div class="card-body">
      <button
        class="btn btn-dark"
        @click="fetchPosts"
      >
        Fetch posts
      </button>
      <button
        class="btn btn-dark"
        @click="clearPosts"
      >
        Clear posts
      </button>
      <hr />
      <div class="list-group">
        <div
          class="list-group-item"
          v-for="post in posts"
        >
          {{ post.title }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import { mapState, mapActions } from 'vuex';

  export default {
    /**
     * The name of the page.
     */
    name: 'posts-page',

    /**
     * The computed properties that this page can use.
     */
    computed: {
      ...mapState({
        // this.posts = $store.state.post.all
        posts: state => state.post.all,
      }),
    },

    /**
     * The methods that are available on this page.
     */
    methods: {
      ...mapActions({
        // this.fetchPosts = $store.dispatch('post/fetch');
        fetchPosts: 'post/fetch',

        // this.clearPosts = $store.dispatch('post/clear');
        clearPosts: 'post/clear',
      }),
    },
  };
</script>
