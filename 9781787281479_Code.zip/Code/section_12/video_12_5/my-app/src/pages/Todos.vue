<template>
  <div class="card">
    <h4 class="card-header bg-dark text-white">
      Todos Page
    </h4>
    <div class="card-body">
      <button
        class="btn btn-dark"
        @click="fetchTodos"
      >
        Fetch todos
      </button>
      <button
        class="btn btn-dark"
        @click="clearTodos"
      >
        Clear todos
      </button>
      <hr />
      <div class="list-group">
        <div
          class="list-group-item"
          v-for="todo in todos"
        >
          {{ todo.title }}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import { mapState, mapActions } from 'vuex';

  export default {
    /**
     * The name of the page.
     */
    name: 'todos-page',

    /**
     * The computed properties that this page can use.
     */
    computed: {
      ...mapState({
        // this.todos = $store.state.todo.all
        todos: state => state.todo.all,
      }),
    },

    /**
     * The methods that are available on this page.
     */
    methods: {
      ...mapActions({
        // this.fetchTodos = $store.dispatch('todo/fetch');
        fetchTodos: 'todo/fetch',

        // this.clearTodos = $store.dispatch('todo/clear');
        clearTodos: 'todo/clear',
      }),
    },
  };
</script>
