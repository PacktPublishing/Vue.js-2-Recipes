<template>
  <div id="app">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
          <router-link
            :to="{ name: 'posts' }"
            class="nav-item"
            tag="li"
          >
            <a class="nav-link">
              Posts
            </a>
          </router-link>
          <router-link
            :to="{ name: 'todos' }"
            class="nav-item"
            tag="li"
          >
            <a class="nav-link">
              Todos
            </a>
          </router-link>
        </ul>
      </div>
    </nav>
    <div class="container mt-4">
      <div class="row justify-content-center">
        <div class="col col-md-6">
          <router-view></router-view>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapActions } from 'vuex';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * Methods that this Vue instance can use.
     */
    methods: {
      ...mapActions({
        // this.fetchPosts = $store.dispatch('post/fetch');
        fetchPosts: 'post/fetch',

        // this.fetchTodos = $store.dispatch('todo/fetch');
        fetchTodos: 'todo/fetch',
      }),
    },

    /**
     * Will be fired when the Vue instance has been mounted.
     */
    mounted() {
      this.fetchPosts();
      this.fetchTodos();
    }
  }
</script>
