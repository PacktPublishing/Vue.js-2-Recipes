import Vue from 'vue';
import './plugins/vuex';
import './plugins/axios';
import { router } from './plugins/vue-router';
import './plugins/vuex-router-sync';
import './plugins/bootstrap';
import store from './store';
import App from './App';

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',

  /**
   * Bind the store to the Vue instance.
   */
  store,

  /**
   * Bind the router to the Vue instance.
   */
  router,

  render: h => h(App)
});
