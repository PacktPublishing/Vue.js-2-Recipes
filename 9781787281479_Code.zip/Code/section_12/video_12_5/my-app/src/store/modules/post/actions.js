import Vue from 'vue';
import * as types from './mutation-types';

export default {
  /**
   * Will fetch all the posts from the API.
   *
   * @param {Function} commit Will commit the mutation.
   */
  fetch({ commit }) {
    Vue.$http
      .get('posts')
      .then(({ data }) => {
        commit(types.FETCH, data);
      })
      .catch((error) => {
        console.log(error);
      });
  },

  /**
   * Will clear the posts from the store.
   *
   * @param {Function} commit Will commit the mutation.
   */
  clear({ commit }) {
    commit(types.CLEAR);
  },
}
