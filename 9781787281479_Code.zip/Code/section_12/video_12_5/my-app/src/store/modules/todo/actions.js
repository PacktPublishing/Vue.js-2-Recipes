import Vue from 'vue';
import * as types from './mutation-types';

export default {
  /**
   * Will fetch all the todos from the API.
   *
   * @param {Function} commit Will commit the mutation.
   */
  fetch({ commit }) {
    Vue.$http
      .get('todos')
      .then(({ data }) => {
        commit(types.FETCH, data);
      })
      .catch((error) => {
        console.log(error);
      });
  },

  /**
   * Will clear the todos from the store.
   *
   * @param {Function} commit Will commit the mutation.
   */
  clear({ commit }) {
    commit(types.CLEAR);
  },
}
