import {
  FETCH,
  CLEAR,
} from './mutation-types';

export default {
  /**
   * Mutation which will fetch all the items.
   *
   * @param {Object} state The current state of the store.
   * @param {Array}  items The items fetched from the API.
   */
  [FETCH](state, items) {
    state.all = items;
  },

  /**
   * Mutation which will clear the posts from the store.
   *
   * @param {Object} state The current state of the store.
   */
  [CLEAR](state) {
    state.all = [];
  },
}
