import Vue from 'vue'
import App from './App'
import 'bootstrap/dist/css/bootstrap.css'
import store from './store'
import Axios from 'axios';

// Set the base URL
Axios.defaults.baseURL = 'https://jsonplaceholder.typicode.com';
Axios.defaults.headers.common.Accept = 'application/json';

// Bind Axios to Vue
Vue.$http = Axios;
Object.defineProperty(Vue.prototype, '$http', {
  get() {
    return Axios;
  }
});

Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  el: '#app',

  /**
   * Bind the store to the Vue instance.
   */
  store,

  render: h => h(App)
})
