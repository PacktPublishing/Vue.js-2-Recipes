export default {
  /**
   * The mutation which will fetch the todos.
   *
   * @param {Object} state The state.
   * @param {Array}  todos The todos fetched from the API.
   */
  fetchTodos(state, todos) {
    state.todos = todos;
  },
};
