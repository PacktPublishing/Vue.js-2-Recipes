import Vue from 'vue';
import Vuex from 'vuex';
import state from './state';
import actions from './actions';
import mutations from './mutations';

Vue.use(Vuex);

const debug = process.env.NODE_ENV !== 'production';

export default new Vuex.Store({
  /**
   * The state of the store.
   */
  state,

  /**
   * The actions this store can dispatch.
   */
  actions,

  /**
   * The mutations this store can commit.
   */
  mutations,

  /**
   * If strict mode should be enabled.
   */
  strict: debug,
});
