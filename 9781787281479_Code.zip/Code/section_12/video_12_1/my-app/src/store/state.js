export default {
  /**
   * The array of todos.
   */
  todos: [],
};

