<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-10">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Managing your Application’s State with Vuex
            </h4>
            <div class="card-body">
              <div class="form-group">
                <button
                  class="btn btn-primary"
                  @click="fetchTodos"
                >
                  Fetch todos!
                </button>
              </div>
              <hr />
              <table class="table table-hover table-sm">
                <thead>
                <tr>
                  <th>#</th>
                  <th>Title</th>
                  <th>Is Completed?</th>
                </tr>
                </thead>
                <tbody>
                <tr
                  v-for="todo in todos"
                  :key="todo.id"
                >
                  <th>{{ todo.id }}</th>
                  <td>{{ todo.title }}</td>
                  <td>{{ todo.completed }}</td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapState } from 'vuex';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The computed properties this Vue instance can use.
     */
    computed: {
      ...mapState([
        // this.todos = $store.state.todos
        'todos',
      ]),
    },

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      /**
       * Used to fetch all the todos from the API.
       * Will dispatch the `fetchTodos`-action.
       */
      fetchTodos() {
        this.$store.dispatch('fetchTodos');
      },
    },
  }
</script>
