import {
  ADD,
  REMOVE,
  TOGGLE,
} from './mutation-types';

export default {
  /**
   * Mutation which will add a new todo to the array of todos.
   *
   * @param {Object} state The state of the application.
   * @param {String} todo  The new todo item.
   */
  [ADD](state, todo) {
    // Create a copy of the todos array and grab the last item.
    const lastTodo = state.all.slice(-1).pop();

    state.all.push({
      title: todo,
      completed: false,
      id: lastTodo ? lastTodo.id + 1 : 1,
    });
  },

  /**
   * Mutation which will remove a todo.
   *
   * @param {Object} state The state of the application.
   * @param {Object} todo  The todo to be removed.
   */
  [REMOVE](state, todo) {
    state.all = state.all.filter(item => item !== todo);
  },

  /**
   * Mutation which will toggle a todo.
   *
   * @param {Object} state The state of the application.
   * @param {Object} todo  The todo to be toggled.
   */
  [TOGGLE](state, todo) {
    const foundTodo = state.all.find(item => item === todo);

    foundTodo.completed = !foundTodo.completed;
  },
}
