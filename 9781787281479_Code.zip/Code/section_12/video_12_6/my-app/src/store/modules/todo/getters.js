export default {
  /**
   * Getter for the finished todos.
   *
   * @param {Object} state The current state.
   *
   * @return {Array} The array of finished todos.
   */
  finished: state => state.all.filter(todo => todo.completed),

  /**
   * Getter for the unfinished todos.
   *
   * @param {Object} state The current state.
   *
   * @return {Array} The array of unfinished todos.
   */
  unfinished: state => state.all.filter(todo => !todo.completed),
};
