export const ADD = 'ADD';
export const REMOVE = 'REMOVE';
export const TOGGLE = 'TOGGLE';

export default {
  ADD,
  REMOVE,
  TOGGLE,
};
