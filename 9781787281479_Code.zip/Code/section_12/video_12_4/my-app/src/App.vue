<template>
  <div id="app">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col col-10">
          <div class="card">
            <h4 class="card-header bg-dark text-white">
              Managing your Application’s State with Vuex
            </h4>
            <div class="card-body">
              <button
                class="btn btn-dark"
                @click="fetchTodos"
              >
                Fetch todos
              </button>
              <button
                class="btn btn-dark"
                @click="removeTodos"
              >
                Remove todos
              </button>
              <hr />
              <div class="list-group">
                <div
                  class="list-group-item"
                  v-for="todo in todos"
                  :key="todo.id"
                >{{ todo.title }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapState, mapActions } from 'vuex';

  export default {
    /**
     * The name of the application.
     */
    name: 'my-app',

    /**
     * The computed properties this Vue instance can use.
     */
    computed: {
      ...mapState([
        // this.todos = $store.state.todos
        'todos',
      ])
    },

    /**
     * The methods that can be used by this Vue instance.
     */
    methods: {
      ...mapActions([
        // this.fetchTodos = $store.dispatch('fetchTodos')
        'fetchTodos',

        // this.removeTodos = $store.dispatch('removeTodos')
        'removeTodos',
      ]),
    },
  }
</script>
