import {
  FETCH_TODOS,
  REMOVE_TODOS,
} from './mutation-types';
export default {
  /**
   * The mutation which will fetch the todos.
   *
   * @param {Object} state The state.
   * @param {Array}  todos The todos fetched from the API.
   */
  [FETCH_TODOS](state, todos) {
    state.todos = todos;
  },

  /**
   * The mutation which will remove the todos.
   *
   * @param {Object} state The state.
   */
  [REMOVE_TODOS](state) {
    state.todos = [];
  },
};
