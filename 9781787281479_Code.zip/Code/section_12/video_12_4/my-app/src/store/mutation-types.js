export const FETCH_TODOS = 'FETCH_TODOS';
export const REMOVE_TODOS = 'REMOVE_TODOS';

export default {
  FETCH_TODOS,
  REMOVE_TODOS,
};
